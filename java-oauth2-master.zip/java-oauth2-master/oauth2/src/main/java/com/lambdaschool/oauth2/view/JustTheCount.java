package com.lambdaschool.oauth2.view;

public interface JustTheCount
{
    int getCount();
}
